# Text-to-Image Generator using Stable Diffusion

This project generates images from text prompts using a pre-trained Stable Diffusion model.

## Setup

```bash
pip install -r requirements.txt
```

> Make sure you have a Hugging Face token and are logged in using:
```bash
huggingface-cli login
```

## Usage

```bash
python main.py
```

Then enter a prompt like:
```
A castle in the clouds during sunset
```

The generated image will be saved as `output.png`.
