from diffusers import StableDiffusionPipeline
import torch

def generate_image(prompt, output_path="output.png"):
    # Load pre-trained stable diffusion model
    pipe = StableDiffusionPipeline.from_pretrained(
        "CompVis/stable-diffusion-v1-4", 
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        use_auth_token=True  # Requires Hugging Face login
    ).to("cuda" if torch.cuda.is_available() else "cpu")

    # Generate image
    image = pipe(prompt).images[0]
    image.save(output_path)
    print(f"Image saved to {output_path}")

if __name__ == "__main__":
    prompt = input("Enter your prompt: ")
    generate_image(prompt)
